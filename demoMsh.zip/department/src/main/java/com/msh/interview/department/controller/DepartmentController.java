package com.msh.interview.department.controller;

import com.msh.interview.department.entity.Department;
import com.msh.interview.department.entity.Organization;
import com.msh.interview.department.service.DepartmentService;
import com.msh.interview.department.service.fiegnService.OrganizationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/msh")
public class DepartmentController {
    private static final Logger logger= LoggerFactory.getLogger(DepartmentController.class);


    @Autowired
    private DepartmentService departmentService;

    @Autowired
    private OrganizationService organizationService;

    @GetMapping("/departments/{id}")
    public Department getDepartmentById(@PathVariable long id){
        logger.info(">>>> DepartmentController method getDepartmentById - started");
        Department department = departmentService.getDepartmentById(id);
        department.setOrganization(organizationService.getOrganizationById(department.getOrganizationId()));
        logger.info(">>>> DepartmentController method getDepartmentById - ended");
        return department;
    }

    @PostMapping("/departments")
    public String createDepartment(@RequestBody Department department){
        return departmentService.createDepartment(department);
    }

    @DeleteMapping("/departments/{id}")
    public String deleteDepartmentById(@PathVariable long id){
        return departmentService.deleteDepartmentById(id);
    }

    @GetMapping("/departments")
    public List<Department> getAllDepartment() {
        return departmentService.getAllDepartment();
    }

}
