package com.msh.interview.department.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Data
@NoArgsConstructor
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @NotNull(message="Department name cannot be null")
    @Size(min=2, message = "Department name must not be less than 2 characters")
    private String name;
    private long organizationId;
    @Transient
    private Organization organization;

}
