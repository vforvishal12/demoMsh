package com.msh.interview.department.service;

import com.msh.interview.department.dao.DepartmentDaoIF;
import com.msh.interview.department.entity.Department;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DepartmentService {

    @Autowired
    private DepartmentDaoIF departmentDao;

    public Department getDepartmentById(long id){
        return departmentDao.findById(id).get();
    }

    public String createDepartment(Department department){
        departmentDao.save(department);
        return "Created successfully.";
    }

    public String deleteDepartmentById(long id){
        departmentDao.deleteById(id);
        return "Deleted successfully.";
    }

    public List<Department> getAllDepartment() {
        List<Department> departmentList=new ArrayList<>();
        departmentDao.findAll().forEach(departmentList::add);
        return departmentList;
    }

}
