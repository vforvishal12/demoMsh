package com.msh.interview.department.service.fiegnService;

import com.msh.interview.department.entity.Organization;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient("mshOrganization")
public interface OrganizationService {

    @GetMapping("/msh/organizations/{id}")
    public Organization getOrganizationById(@PathVariable long id);

}
