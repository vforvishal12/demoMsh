package com.msh.interview.department.dao;

import com.msh.interview.department.entity.Department;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DepartmentDaoIF extends CrudRepository<Department, Long>{
}
