package com.msh.interview.employee.controller;

import com.msh.interview.employee.dao.EmployeeDaoIF;
import com.msh.interview.employee.entity.Department;
import com.msh.interview.employee.entity.Employee;
import com.msh.interview.employee.entity.EmployeeResponse;
import com.msh.interview.employee.entity.Organization;
import com.msh.interview.employee.service.EmployeeService;
import com.msh.interview.employee.service.fiegnService.DepartmentService;
import org.aspectj.weaver.ast.Or;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/msh")
public class EmployeeController {
    private static final Logger logger= LoggerFactory.getLogger(EmployeeController.class);

    @Autowired
    private EmployeeService employeeService;

    @Autowired
    private DepartmentService departmentService;

    @GetMapping("/employees/{id}")
    public EmployeeResponse getEmployeeById(@PathVariable long id){
        logger.info(">>>> EmployeeController method getEmployeeById - started");
        Employee employee = employeeService.getEmployeeById(id);
        Department department =departmentService.getDepartmentById(employee.getDepartmentId());
        Organization organization = department.getOrganization();

        EmployeeResponse response = new EmployeeResponse();
        response.setEmployeeId(employee.getId());
        response.setEmployeeName(employee.getName());
        response.setDepartmentName(department.getName());
        response.setOrganizationName(organization.getName());
        response.setOrganizationAddress(organization.getAddress());
        logger.info(">>>> EmployeeController method getEmployeeById - ended");
        return response;
    }

    @PostMapping("/employees")
    public String createEmployee(@RequestBody Employee employee){
        return employeeService.createEmployee(employee);
    }

    @DeleteMapping("/employees/{id}")
    public String deleteEmployeeById(@PathVariable long id){
        return employeeService.deleteEmployeeById(id);
    }

    @GetMapping("/employees")
    public List<Employee> getAllEmployee() {
        return employeeService.getAllEmployee();
    }

    @PutMapping("/employees")
    public Employee updateEmployee(@RequestBody Employee employee) {
        return employeeService.updateEmployee(employee);
    }
}
