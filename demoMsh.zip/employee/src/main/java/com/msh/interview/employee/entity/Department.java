package com.msh.interview.employee.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Data
@NoArgsConstructor
public class Department {

    private long id;
    private String name;
    private long organizationId;
    private Organization organization;

}
