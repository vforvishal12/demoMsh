package com.msh.interview.employee.service;

import com.msh.interview.employee.dao.EmployeeDaoIF;
import com.msh.interview.employee.entity.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeDaoIF employeeDao;

    public Employee getEmployeeById(long id){
        return employeeDao.findById(id).get();
    }

    public String createEmployee(Employee employee){
        employeeDao.save(employee);
        return "Created successfully.";
    }

    public String deleteEmployeeById(long id){
        employeeDao.deleteById(id);
        return "Deleted successfully.";
    }

    public List<Employee> getAllEmployee() {
        List<Employee> employeeList=new ArrayList<>();
        employeeDao.findAll().forEach(employeeList::add);
        return employeeList;
    }


    public Employee updateEmployee(Employee employee) {
        return  employeeDao.save(employee);
    }
}
