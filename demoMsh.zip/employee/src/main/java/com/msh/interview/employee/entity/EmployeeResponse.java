package com.msh.interview.employee.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EmployeeResponse {

    private long employeeId;
    private String employeeName;
    private String departmentName;
    private String organizationName;
    private String organizationAddress;

}
