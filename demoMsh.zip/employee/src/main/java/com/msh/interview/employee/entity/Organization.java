package com.msh.interview.employee.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Organization {
    private long id;
    private String name;
    private String address;

}
