package com.msh.interview.employee.exception;

public class CustomException extends RuntimeException{
    public CustomException(String message) {
        super(message);
    }
}
