package com.msh.interview.employee.dao;

import com.msh.interview.employee.entity.Employee;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeDaoIF extends CrudRepository<Employee, Long> {
}
