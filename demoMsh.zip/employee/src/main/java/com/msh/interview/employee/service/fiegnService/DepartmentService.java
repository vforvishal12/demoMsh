package com.msh.interview.employee.service.fiegnService;

import com.msh.interview.employee.entity.Department;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient("mshDepartment")
public interface DepartmentService {

    @GetMapping("/msh/departments/{id}")
    public Department getDepartmentById(@PathVariable long id);
}
