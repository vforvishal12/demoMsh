package com.msh.interview.employee;

import com.msh.interview.employee.dao.EmployeeDaoIF;
import com.msh.interview.employee.entity.Employee;
import com.msh.interview.employee.service.EmployeeService;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@SpringBootTest
class EmployeeApplicationTests {

	public static final long EMPLOYEE_ID = 1L;
	public static final String EMPLOYEE_NAME = "TEST_EMPLOYEE_NAME";
	public static final long EMPLOYEE_DEPT_ID = 10L;

	@InjectMocks
	EmployeeService employeeService;

	@Mock
	EmployeeDaoIF employeeDao;

	@Test
	public void getEmployeeByIdTest(){

		when(employeeDao.findById(EMPLOYEE_ID))
				.thenReturn(Optional.of(new Employee(EMPLOYEE_ID, EMPLOYEE_NAME, EMPLOYEE_DEPT_ID)));
		Employee emp = employeeService.getEmployeeById(EMPLOYEE_ID);
		assertEquals(EMPLOYEE_ID, emp.getId());
		assertEquals(EMPLOYEE_NAME, emp.getName());
		assertEquals(EMPLOYEE_DEPT_ID, emp.getDepartmentId());
	}

	@Test
	public void createEmployeeTest()
	{
		Employee emp = new Employee(EMPLOYEE_ID, EMPLOYEE_NAME, EMPLOYEE_DEPT_ID);
		employeeService.createEmployee(emp);
		verify(employeeDao, times(1)).save(emp);
	}

	@Test
	public void deleteById() {
		Employee emp = new Employee(EMPLOYEE_ID, EMPLOYEE_NAME, EMPLOYEE_DEPT_ID);
		employeeService.createEmployee(emp);
		employeeService.deleteEmployeeById(EMPLOYEE_ID);
		Optional optional = employeeDao.findById(EMPLOYEE_ID);
		assertEquals(Optional.empty(), optional);

	}
}
