package com.msh.interview.organization.exception;

import com.msh.interview.organization.entity.CustomExceptionMessage;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDate;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@ControllerAdvice
public class CustomExceptionHandler extends ResponseEntityExceptionHandler {
    private static final Logger logger= LoggerFactory.getLogger(CustomExceptionHandler.class);

    @ExceptionHandler(value = {Exception.class})
    public ResponseEntity<Object> handleAnyException(Exception ex, WebRequest request) {
        String msg = ex.getLocalizedMessage();
        if (msg == null) msg = ex.toString();
        logger.error(">>>> CustomExceptionHandler method handleAnyException - msg "+msg);
        CustomExceptionMessage errorMessage = new CustomExceptionMessage(new Date(), msg);
        return new ResponseEntity<>(
                errorMessage, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @ExceptionHandler(value = {NullPointerException.class, CustomException.class})
    public ResponseEntity<Object> handleSpecificExceptions(Exception ex, WebRequest request) {
        String msg = ex.getLocalizedMessage();
        if (msg == null) msg = ex.toString();
        logger.error(">>>> CustomExceptionHandler method handleSpecificExceptions - msg "+msg);
        CustomExceptionMessage errorMessage = new CustomExceptionMessage(new Date(), msg);
        return new ResponseEntity<>(
                errorMessage, new HttpHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(
            MethodArgumentNotValidException ex, HttpHeaders headers,
            HttpStatus status, WebRequest request) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("timestamp", LocalDate.now());
        body.put("status", status.value());
        List<String> errors = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(x -> x.getDefaultMessage())
                .collect(Collectors.toList());
        body.put("errors", errors);
        logger.error(">>>> CustomExceptionHandler method handleMethodArgumentNotValid - msg "+errors);
        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }
}
