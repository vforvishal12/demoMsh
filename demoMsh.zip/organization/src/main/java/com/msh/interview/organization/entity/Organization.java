package com.msh.interview.organization.entity;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Data
@Entity
@NoArgsConstructor
public class Organization {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @NotNull(message="Organization name cannot be null")
    @Size(min=2, message = "Organization name must not be less than 2 characters")
    private String name;
    @NotNull(message="Organization address cannot be null")
    @Size(min=2, message = "Organization address must not be less than 2 characters")
    private String address;

}
