package com.msh.interview.organization.controller;

import com.msh.interview.organization.entity.Organization;
import com.msh.interview.organization.service.OrganizationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/msh")
public class OrganizationController {
    private static final Logger logger= LoggerFactory.getLogger(OrganizationController.class);

    @Autowired
    private OrganizationService organizationService;

    @GetMapping("/organizations")
    public List<Organization> getAllOrganization(){
        return organizationService.getAllOrganization();
    }

    @GetMapping("/organizations/{id}")
    public Organization getOrganizationById(@PathVariable long id){
        logger.info(">>>> OrganizationController method getOrganizationById ");
        return organizationService.getOrganizationById(id);
    }

    @PostMapping("/organizations")
    public String createOrganization(@RequestBody Organization organization){
        return organizationService.createOrganization(organization);
    }

    @DeleteMapping("/organizations/{id}")
    public String deleteOrganizationById(@PathVariable long id){
        return organizationService.deleteOrganizationById(id);
    }

}
