package com.msh.interview.organization.service;

import com.msh.interview.organization.dao.OrganizationDaoIF;
import com.msh.interview.organization.entity.Organization;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class OrganizationService {

    @Autowired
    private OrganizationDaoIF organizationDao;

    public Organization getOrganizationById(long id){
        return organizationDao.findById(id).get();
    }

    public String createOrganization(Organization organization){
        organizationDao.save(organization);
        return "Created successfully.";
    }

    public String deleteOrganizationById(long id){
        organizationDao.deleteById(id);
        return "Deleted successfully.";
    }


    public List<Organization> getAllOrganization() {
        List<Organization> organizationList=new ArrayList<>();
         organizationDao.findAll().forEach(organizationList::add);
        return organizationList;
    }
}
