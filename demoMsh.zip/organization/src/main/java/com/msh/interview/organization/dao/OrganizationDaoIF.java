package com.msh.interview.organization.dao;

import com.msh.interview.organization.entity.Organization;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrganizationDaoIF extends CrudRepository<Organization, Long> {
}
